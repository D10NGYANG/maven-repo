@file:OptIn(InternalResourceApi::class)

package com.d10ng.compose.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/com.d10ng.compose.resources/"

@delegate:ResourceContentHash(-2_136_679_280)
internal val Res.drawable.ic_baseline_arrow_drop_down_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_baseline_arrow_drop_down_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_baseline_arrow_drop_down_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-429_782_376)
internal val Res.drawable.ic_baseline_arrow_drop_up_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_baseline_arrow_drop_up_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_baseline_arrow_drop_up_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-424_696_673)
internal val Res.drawable.ic_baseline_keyboard_arrow_right_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_baseline_keyboard_arrow_right_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_baseline_keyboard_arrow_right_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-814_244_739)
internal val Res.drawable.ic_baseline_visibility_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_baseline_visibility_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_baseline_visibility_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-624_474_015)
internal val Res.drawable.ic_baseline_visibility_off_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_baseline_visibility_off_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_baseline_visibility_off_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(176_818_554)
internal val Res.drawable.ic_false_102: DrawableResource by lazy {
      DrawableResource("drawable:ic_false_102", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_false_102.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_168_317_018)
internal val Res.drawable.ic_round_add_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_add_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_add_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(953_272_316)
internal val Res.drawable.ic_round_add_circle_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_add_circle_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_add_circle_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_166_862_855)
internal val Res.drawable.ic_round_back_22: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_back_22", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_back_22.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_694_674_041)
internal val Res.drawable.ic_round_cancel_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_cancel_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_cancel_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(689_068_875)
internal val Res.drawable.ic_round_check_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_check_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_check_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_877_428_576)
internal val Res.drawable.ic_round_error_160: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_error_160", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_error_160.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(899_546_356)
internal val Res.drawable.ic_round_forward_16: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_forward_16", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_forward_16.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(264_037_646)
internal val Res.drawable.ic_round_remove_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_remove_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_remove_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-342_431_819)
internal val Res.drawable.ic_round_remove_circle_24: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_remove_circle_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_remove_circle_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_617_851_632)
internal val Res.drawable.ic_round_search_22: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_search_22", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_search_22.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_091_281_236)
internal val Res.drawable.ic_round_steps_active_20: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_steps_active_20", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_steps_active_20.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(341_547_780)
internal val Res.drawable.ic_round_success_160: DrawableResource by lazy {
      DrawableResource("drawable:ic_round_success_160", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_round_success_160.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_939_142_503)
internal val Res.drawable.ic_success_102: DrawableResource by lazy {
      DrawableResource("drawable:ic_success_102", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_success_102.xml", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("ic_baseline_arrow_drop_down_24", Res.drawable.ic_baseline_arrow_drop_down_24)
  map.put("ic_baseline_arrow_drop_up_24", Res.drawable.ic_baseline_arrow_drop_up_24)
  map.put("ic_baseline_keyboard_arrow_right_24", Res.drawable.ic_baseline_keyboard_arrow_right_24)
  map.put("ic_baseline_visibility_24", Res.drawable.ic_baseline_visibility_24)
  map.put("ic_baseline_visibility_off_24", Res.drawable.ic_baseline_visibility_off_24)
  map.put("ic_false_102", Res.drawable.ic_false_102)
  map.put("ic_round_add_24", Res.drawable.ic_round_add_24)
  map.put("ic_round_add_circle_24", Res.drawable.ic_round_add_circle_24)
  map.put("ic_round_back_22", Res.drawable.ic_round_back_22)
  map.put("ic_round_cancel_24", Res.drawable.ic_round_cancel_24)
  map.put("ic_round_check_24", Res.drawable.ic_round_check_24)
  map.put("ic_round_error_160", Res.drawable.ic_round_error_160)
  map.put("ic_round_forward_16", Res.drawable.ic_round_forward_16)
  map.put("ic_round_remove_24", Res.drawable.ic_round_remove_24)
  map.put("ic_round_remove_circle_24", Res.drawable.ic_round_remove_circle_24)
  map.put("ic_round_search_22", Res.drawable.ic_round_search_22)
  map.put("ic_round_steps_active_20", Res.drawable.ic_round_steps_active_20)
  map.put("ic_round_success_160", Res.drawable.ic_round_success_160)
  map.put("ic_success_102", Res.drawable.ic_success_102)
}
