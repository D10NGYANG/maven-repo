package com.d10ng.crypto

internal fun cleanRSAKey(key: String): String = key
    .replace(Regex("-----(?:BEGIN|END) (?:RSA )?(?:PUBLIC|PRIVATE) KEY-----"), "")
    .filterNot { it.isWhitespace() }

internal fun joinRSABytes(blocks: List<ByteArray>): ByteArray {
    val size = blocks.fold(0L) { total, bytes -> total + bytes.size }
    require(size <= Int.MAX_VALUE) { "RSA data too large" }
    val result = ByteArray(size.toInt())
    var offset = 0
    blocks.forEach { it.copyInto(result, offset); offset += it.size }
    return result
}

internal fun decodeRSACiphertext(data: String): ByteArray {
    require(data.isNotEmpty()) { "RSA ciphertext must not be empty" }
    // 兼容旧 iOS 的逐块 Base64 格式；新密文统一整体 Base64。
    return joinRSABytes(data.split('|').map {
        require(it.isNotEmpty()) { "Empty RSA ciphertext block" }
        it.decodeBase64ToByteArray()
    })
}

internal fun rsaBlockSize(keyBytes: Int, fillMode: RSAFillMode, hash: HashAlgorithm?): Int {
    val overhead = when (fillMode) {
        RSAFillMode.NoPadding -> 0
        RSAFillMode.PKCS1Padding -> 11
        RSAFillMode.OAEP -> 2 * when (requireNotNull(hash) { "OAEP requires a hash" }) {
            HashAlgorithm.SHA1 -> 20
            HashAlgorithm.SHA256 -> 32
        } + 2
    }
    return (keyBytes - overhead).also { require(it > 0) { "RSA key too small for padding" } }
}

internal fun validateRSAInput(size: Int, blockSize: Int, fullBlocks: Boolean) {
    require(size > 0) { "RSA input must not be empty" }
    require(blockSize > 0 && (!fullBlocks || size % blockSize == 0)) {
        "RSA ciphertext and NoPadding plaintext must contain complete key-sized blocks"
    }
}

private val rsaAlgorithmIdentifier = byteArrayOf(0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86.toByte(),
    0x48, 0x86.toByte(), 0xf7.toByte(), 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00)

private fun der(tag: Int, value: ByteArray): ByteArray {
    val length = value.size
    val bytes = if (length < 128) byteArrayOf(length.toByte()) else {
        val encoded = (3 downTo 0).map { (length ushr (it * 8)).toByte() }.dropWhile { it == 0.toByte() }.toByteArray()
        byteArrayOf((0x80 or encoded.size).toByte()) + encoded
    }
    return byteArrayOf(tag.toByte()) + bytes + value
}

internal fun wrapRSAKey(pkcs1: ByteArray, publicKey: Boolean): ByteArray = der(0x30,
    if (publicKey) rsaAlgorithmIdentifier + der(0x03, byteArrayOf(0) + pkcs1)
    else byteArrayOf(0x02, 0x01, 0x00) + rsaAlgorithmIdentifier + der(0x04, pkcs1))

// 只解析 RSA 标准包装；整数内容交由平台密钥解析器验证。
private class DERReader(private val bytes: ByteArray) {
    private var offset = 0
    fun done() = offset == bytes.size
    fun peek(): Int { require(offset < bytes.size) { "Truncated DER" }; return bytes[offset].toInt() and 255 }
    fun read(tag: Int): ByteArray {
        require(peek() == tag) { "Unexpected DER tag" }; offset++
        val first = peek(); offset++
        var length = first.toLong()
        if (first >= 128) {
            val count = first and 127
            require(count in 1..4 && count <= bytes.size - offset) { "Invalid DER length" }
            require(peek() != 0) { "Non-canonical DER length" }
            length = 0
            repeat(count) { length = (length shl 8) or peek().toLong(); offset++ }
            require(length >= 128) { "Non-canonical DER length" }
        }
        require(length <= bytes.size - offset) { "Truncated DER value" }
        return bytes.copyOfRange(offset, offset + length.toInt()).also { offset += length.toInt() }
    }
}

internal fun unwrapRSAKey(encoded: ByteArray, publicKey: Boolean): ByteArray {
    val outer = DERReader(encoded)
    val body = DERReader(outer.read(0x30))
    require(outer.done()) { "Trailing DER data" }
    if (publicKey && body.peek() == 0x02) return encoded
    if (!publicKey) {
        require(body.read(0x02).contentEquals(byteArrayOf(0))) { "Unsupported RSA key version" }
        if (body.peek() == 0x02) return encoded
    }
    val algorithm = der(0x30, body.read(0x30))
    require(algorithm.contentEquals(rsaAlgorithmIdentifier)) { "Not an rsaEncryption key" }
    val key = body.read(if (publicKey) 0x03 else 0x04)
    require(body.done()) { "Unsupported RSA key attributes" }
    if (!publicKey) return key
    require(key.isNotEmpty() && key[0] == 0.toByte()) { "Invalid RSA bit string" }
    return key.copyOfRange(1, key.size)
}
