package com.d10ng.crypto

import kotlin.js.JsExport

// 密钥格式
@JsExport
enum class KeyFormat {
    PKCS1, PKCS8
}
// 填充模式
@JsExport
enum class RSAFillMode {
    NoPadding, OAEP, PKCS1Padding
}
// 加密模式
@JsExport
enum class RSAEncryptMode {
    NONE, ECB
}
// 哈希算法
@JsExport
enum class HashAlgorithm {
    SHA1, SHA256
}
// MGF哈希算法
@JsExport
enum class MGFHashAlgorithm {
    SHA1, SHA256
}

/**
 * 生成RSA密钥对
 * @param keyFormat KeyFormat 密钥格式，默认PKCS1
 * @param keyLength Int 密钥长度，默认2048位，可以根据需要调整，建议2048及以上
 * @return Array<String> 裸 Base64 DER 公钥和私钥；PKCS8 公钥为 SPKI
 */
expect fun generateRSAKeyPair(keyFormat: KeyFormat = KeyFormat.PKCS1, keyLength: Int = 2048): Array<String>


/**
 * # RSA公钥加密
 * > RSA加密解密算法支持三种填充模式，分别是NoPadding、OAEP、PKCS1Padding，RSA填充是为了和公钥等长。
 * - OAEP：最优非对称加密填充，英文为：Optimal Asymmetric Encryption Padding，是RSA加密和RSA解密最新最安全的推荐填充模式。当填充模式选择OAEP时，必须选择参数Hash和MGFHash。
 * - PKCS1Padding：随机填充数据模式，每次加密的结果都不一样，是RSA加密和RSA解密使用最为广泛的填充模式。当填充模式选择PKCS1Padding时，无须选择参数Hash和MGFHash。
 * - NoPadding：不填充模式，是RSA加密和RSA解密使用较少的填充模式。当填充模式选择NoPadding时，无须选择参数Hash和MGFHash。
 * @param data String 非空待加密数据；NoPadding 的 UTF-8 字节长度必须是模数字节数的整数倍
 * @param publicKey String 公钥
 * @param encryptMode RSAEncryptMode 加密模式，默认RSAEncryptMode.ECB
 * @param fillMode RSAFillMode 填充模式，默认RSAFillMode.PKCS1Padding
 * @param hashAlgorithm HashAlgorithm 哈希算法，默认null
 * @param mgfHashAlgorithm MGFHashAlgorithm OAEP 必填；iOS 要求与 hashAlgorithm 相同
 * @return String 加密后的数据
 */
expect fun rsaPublicEncrypt(
    data: String,
    publicKey: String,
    encryptMode: RSAEncryptMode = RSAEncryptMode.ECB,
    fillMode: RSAFillMode = RSAFillMode.PKCS1Padding,
    hashAlgorithm: HashAlgorithm? = null,
    mgfHashAlgorithm: MGFHashAlgorithm? = null
): String

/**
 * # RSA私钥解密
 * > RSA加密解密算法支持三种填充模式，分别是NoPadding、OAEP、PKCS1Padding，RSA填充是为了和公钥等长。
 * - OAEP：最优非对称加密填充，英文为：Optimal Asymmetric Encryption Padding，是RSA加密和RSA解密最新最安全的推荐填充模式。当填充模式选择OAEP时，必须选择参数Hash和MGFHash。
 * - PKCS1Padding：随机填充数据模式，每次加密的结果都不一样，是RSA加密和RSA解密使用最为广泛的填充模式。当填充模式选择PKCS1Padding时，无须选择参数Hash和MGFHash。
 * - NoPadding：不填充模式，是RSA加密和RSA解密使用较少的填充模式。当填充模式选择NoPadding时，无须选择参数Hash和MGFHash。
 * @param data String 非空 Base64 密文，也接受旧 iOS 的 | 分块格式
 * @param privateKey String 私钥
 * @param encryptMode RSAEncryptMode 加密模式，默认RSAEncryptMode.ECB
 * @param fillMode RSAFillMode 填充模式，默认RSAFillMode.PKCS1Padding
 * @param hashAlgorithm HashAlgorithm 哈希算法，默认null
 * @param mgfHashAlgorithm MGFHashAlgorithm OAEP 必填；iOS 要求与 hashAlgorithm 相同
 * @return String 解密后的数据
 */
expect fun rsaPrivateDecrypt(
    data: String,
    privateKey: String,
    encryptMode: RSAEncryptMode = RSAEncryptMode.ECB,
    fillMode: RSAFillMode = RSAFillMode.PKCS1Padding,
    hashAlgorithm: HashAlgorithm? = null,
    mgfHashAlgorithm: MGFHashAlgorithm? = null
): String
