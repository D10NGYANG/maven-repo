package com.d10ng.crypto

import kotlin.js.JsExport

// 工作模式
@JsExport
enum class AESMode {
    ECB, CBC
}

// 填充模式
@JsExport
enum class AESFillMode {
    PKCS7Padding
}

/**
 * 对密钥进行校验与补位
 * > 校验：
 * - 判断密钥是否为空，如果为空则抛出异常
 * - 判断密钥长度是否超过32位，如果超过则抛出异常
 * - 判断密钥是否只包含字母和数字，如果不是则抛出异常
 * > 补位：
 * - 如果密钥长度不足最近标准长度的（如16、24、32），则在前面补0
 * @param key String
 * @return String
 */
private fun checkAndFillKey(key: String): String {
    if (key.isEmpty()) {
        throw IllegalArgumentException("密钥不能为空")
    }
    if (key.length > 32) {
        throw IllegalArgumentException("密钥长度不能超过32位")
    }
    if (!key.matches(Regex("[a-zA-Z0-9]+"))) {
        throw IllegalArgumentException("密钥只能包含字母和数字")
    }
    val keyLength = key.length
    return when {
        keyLength <= 16 -> key.padStart(16, '0')
        keyLength <= 24 -> key.padStart(24, '0')
        else -> key.padStart(32, '0')
    }
}

private fun checkIv(iv: String?): String {
    require(iv != null && iv.length == 16) { "CBC 向量必须为16位，每次加密应使用新的随机向量" }
    require(iv.matches(Regex("[a-zA-Z0-9]+"))) { "向量只能包含字母和数字" }
    return iv
}

/**
 * AES加密
 * @param content String 待加密内容
 * @param aesMode AESMode 工作模式
 * @param fillMode AESFillMode 填充模式
 * @param key String 密钥，只支持字母与数字，密钥长度支持128位、192位、256位，默认128位，输入的密钥长度不足时，会自动在前面补0
 * @param iv String? CBC 向量，必须显式提供16位字母或数字，每次加密使用新的安全随机值；ECB 忽略
 * @return String
 */
@JsExport
fun aesEncrypt(
    content: String,
    aesMode: AESMode = AESMode.CBC,
    fillMode: AESFillMode = AESFillMode.PKCS7Padding,
    key: String,
    iv: String? = null
): String {
    val keyStr = checkAndFillKey(key)
    val ivStr = if (aesMode == AESMode.ECB) "" else checkIv(iv)
    return aesEncryptDo(content, aesMode, fillMode, keyStr, ivStr)
}

internal expect fun aesEncryptDo(
    content: String,
    aesMode: AESMode = AESMode.CBC,
    fillMode: AESFillMode = AESFillMode.PKCS7Padding,
    key: String,
    iv: String
): String


/**
 * AES解密；CBC 未指定 IV 时仅兼容旧版使用密钥前16位的密文
 * @param content String 待解密内容
 * @param aesMode AESMode 工作模式
 * @param fillMode AESFillMode 填充模式
 * @param key String 密钥，只支持字母与数字，密钥长度支持128位、192位、256位，默认128位，输入的密钥长度不足时，会自动在前面补0
 * @param iv String? CBC 向量，显式值为16位字母或数字；null/空串仅用于旧版默认 IV 密文；ECB 忽略
 * @return String
 */
@JsExport
fun aesDecrypt(
    content: String,
    aesMode: AESMode = AESMode.CBC,
    fillMode: AESFillMode = AESFillMode.PKCS7Padding,
    key: String,
    iv: String? = null
): String {
    val keyStr = checkAndFillKey(key)
    // 保留旧版本未指定 IV 的密文读取，不再用于新加密。
    val ivStr = if (aesMode == AESMode.ECB) "" else checkIv(iv?.takeIf { it.isNotEmpty() } ?: keyStr.take(16))
    val ciphertext = content.decodeBase64ToByteArray()
    require(ciphertext.isNotEmpty() && ciphertext.size % 16 == 0) { "AES 密文必须包含完整的16字节块" }
    return aesDecryptDo(content, aesMode, fillMode, keyStr, ivStr)
}

internal expect fun aesDecryptDo(
    content: String,
    aesMode: AESMode = AESMode.CBC,
    fillMode: AESFillMode = AESFillMode.PKCS7Padding,
    key: String,
    iv: String
): String

// 部分平台仅检查最后一个填充字节；统一校验整个 PKCS7 尾部后再返回明文。
internal fun unpadAES(padded: ByteArray): ByteArray {
    val count = padded.lastOrNull()?.toInt()?.and(255) ?: 0
    require(count in 1..16 && count <= padded.size) { "AES operation failed" }
    var invalid = 0
    for (index in padded.size - count until padded.size) {
        invalid = invalid or ((padded[index].toInt() and 255) xor count)
    }
    require(invalid == 0) { "AES operation failed" }
    return padded.copyOf(padded.size - count)
}
