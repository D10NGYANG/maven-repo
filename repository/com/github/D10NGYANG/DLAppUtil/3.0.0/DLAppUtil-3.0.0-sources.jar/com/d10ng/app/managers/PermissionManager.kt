package com.d10ng.app.managers

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import com.d10ng.app.startup.ctx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 权限管理器
 * @Author d10ng
 * @Date 2023/9/1 11:49
 */
object PermissionManager {

    private val requests = ActivityResultRequests(ActivityResultContracts.RequestMultiplePermissions())

    internal fun onComponentActivityCreated(act: ComponentActivity) = requests.register(act)
    internal fun onComponentActivityDestroyed(act: ComponentActivity) = requests.unregister(act)

    /**
     * 请求权限
     * @param permission String
     * @return Boolean
     */
    suspend fun request(permission: String): Boolean {
        return request(arrayOf(permission))
    }

    /**
     * 请求权限
     * @param permissions Array<String>
     * @return Boolean
     */
    suspend fun request(permissions: Array<String>): Boolean {
        if (has(permissions)) return true
        val result = requests.request(permissions) ?: return false
        return permissions.all { result[it] == true }
    }

    /**
     * 请求管理外部存储空间权限
     * @return Boolean
     */
    @RequiresApi(Build.VERSION_CODES.R)
    suspend fun requestManageExternalStorage(): Boolean = withContext(Dispatchers.Main.immediate) {
        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
            data = "package:${ctx.packageName}".toUri()
        }
        ActivityManager.startActivityForResult(intent)
        Environment.isExternalStorageManager()
    }

    /**
     * 判断是否有外置存储器管理权限
     * @return Boolean
     */
    @RequiresApi(Build.VERSION_CODES.R)
    fun hasManageExternalStorage(): Boolean = Environment.isExternalStorageManager()

    /**
     * 检查权限
     * @param permission String
     * @return Boolean
     */
    fun has(permission: String): Boolean {
        return has(arrayOf(permission))
    }

    /**
     * 检查权限
     * @param permissions Array<out String>
     * @return Boolean
     */
    fun has(permissions: Array<out String>) = permissions.all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }
}