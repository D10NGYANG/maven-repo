package com.d10ng.log

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.atomicfu.locks.synchronized

/**
 * 日志工厂
 * @Author d10ng
 * @Date 2025/9/25 15:12
 */
object LoggerFactory {

    // 日志数据流
    private val _logDataFlow = MutableSharedFlow<LogEntry>(
        extraBufferCapacity = 1024,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val logDataFlow = _logDataFlow

    // Logger列表
    private val lock = SynchronizedObject()
    private var globalLevel = LogLevel.NONE
    private val loggers = mutableMapOf<String, Logger>()

    // Logger列表变更事件
    val loggersChangeEventFlow = MutableSharedFlow<Pair<String, Boolean>>(replay = 1, extraBufferCapacity = 12)

    /**
     * 发送日志数据
     * @param data 日志数据
     */
    internal fun emit(data: LogEntry) {
        _logDataFlow.tryEmit(data)
    }

    /**
     * 创建Logger
     * @param tag 标签
     * @return Logger
     */
    fun create(tag: String): Logger = synchronized(lock) {
        loggers[tag]?.let { return@synchronized it }
        val logger = Logger(tag).apply { miniLevel = globalLevel }
        loggers[tag] = logger
        loggersChangeEventFlow.tryEmit(Pair(tag, true))
        logger
    }

    /**
     * 获取Logger
     * @param tag 标签
     * @return Logger?
     */
    fun get(tag: String): Logger? = synchronized(lock) {
        loggers[tag]
    }

    /**
     * 移除Logger
     * @param tag 标签
     */
    fun remove(tag: String): Unit = synchronized(lock) {
        if (loggers.remove(tag) != null) {
            loggersChangeEventFlow.tryEmit(Pair(tag, false))
        }
    }

    /**
     * 设置日志等级
     * @param tag 标签
     * @param level 日志等级
     */
    fun setLogLevel(tag: String, level: LogLevel): Unit = synchronized(lock) {
        loggers[tag]?.miniLevel = level
    }

    /**
     * 获取日志等级
     * @param tag 标签
     * @return LogLevel
     */
    fun getLogLevel(tag: String): LogLevel? = synchronized(lock) {
        loggers[tag]?.miniLevel
    }

    /**
     * 获取所有Logger
     * @return Map<String, Logger>
     */
    fun getAll(): Map<String, Logger> = synchronized(lock) {
        loggers.toMap()
    }

    /**
     * 设置全局日志等级
     * @param level 日志等级
     */
    fun setGlobalLogLevel(level: LogLevel): Unit = synchronized(lock) {
        globalLevel = level
        loggers.values.forEach {
            it.miniLevel = level
        }
    }
}
