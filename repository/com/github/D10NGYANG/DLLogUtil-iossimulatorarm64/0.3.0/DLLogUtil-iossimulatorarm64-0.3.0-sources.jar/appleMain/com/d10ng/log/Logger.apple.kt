package com.d10ng.log

import platform.Foundation.NSDate
import platform.Foundation.NSDateFormatter
import platform.Foundation.NSString
import platform.Foundation.create
import kotlinx.cinterop.BetaInteropApi
import platform.Foundation.NSLog
import platform.Foundation.dateWithTimeIntervalSince1970

private val dateFormatter = NSDateFormatter().apply {
    dateFormat = "MM-dd HH:mm:ss.SSS"
}

internal fun formatTimestamp(timestamp: Long): String {
    return dateFormatter.stringFromDate(NSDate.dateWithTimeIntervalSince1970(timestamp / 1000.0))
}

private enum class AppleLogLevel(val level: LogLevel, val text: String) {
    VERBOSE(LogLevel.VERBOSE, "💜 VERBOSE"),
    DEBUG(LogLevel.DEBUG, "💚 DEBUG"),
    INFO(LogLevel.INFO, "💙 INFO"),
    WARN(LogLevel.WARN, "💛 WARN"),
    ERROR(LogLevel.ERROR, "❤️ ERROR");
    companion object {
        fun from(level: LogLevel): AppleLogLevel? {
            return entries.firstOrNull { it.level == level }
        }
    }
}

@OptIn(BetaInteropApi::class)
actual fun platformLog(data: LogEntry) {
    if (data.level == LogLevel.NONE) return
    val level = AppleLogLevel.from(data.level) ?: return
    // Bridge explicitly: C string varargs use the system encoding and corrupt UTF-8.
    val message = NSString.create(string = "[${formatTimestamp(data.time)}] ${level.text} [${data.tag}] ${data.message}")
    NSLog("%@", message)
}
