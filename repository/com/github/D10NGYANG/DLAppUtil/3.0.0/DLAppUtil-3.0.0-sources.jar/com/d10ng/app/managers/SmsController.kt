package com.d10ng.app.managers

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.os.Build
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import androidx.core.content.ContextCompat
import androidx.core.database.getLongOrNull
import androidx.core.net.toUri
import com.d10ng.app.startup.ctx
import java.util.UUID
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * 短信管理器
 * @Author d10ng
 * @Date 2024/1/16 15:11
 */
object SmsController {

    data class Data(
        /**
         * 短信ID；接收事件未匹配到收件箱时为 "0"
         * > 会重复的，因为当用户删除短信数据库里的短信后，下一条短信就会重复用这个ID
         */
        var id: String = "",

        /**
         * 订阅 ID（不是卡槽下标），未知为 -1
         */
        var subId: Long = -1,

        /**
         * 来源号码
         */
        var phone: String = "",

        /**
         * 内容
         */
        var content: String = "",

        /**
         * 消息到达的时间戳
         */
        var time: Long = 0
    )

    private val projection = arrayOf("_id", "sub_id", "address", "body", "date")
    private val inboxUri = "content://sms/inbox".toUri()

    // 最新短信接收事件Flow
    private val _receiveFlow = MutableSharedFlow<Data>()
    val receiveFlow = _receiveFlow.asSharedFlow()

    /**
     * 短信监听器
     * > 需要权限：android.permission.RECEIVE_SMS；READ_SMS 可选，用于补全数据库 ID
     */
    class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
                ?.takeIf { it.isNotEmpty() } ?: return
            val first = messages.first()
            val data = Data(
                id = "0",
                subId = intent.getIntExtra("subscription", -1).toLong(),
                phone = first.originatingAddress.orEmpty(),
                content = messages.joinToString("") { it.messageBody.orEmpty() },
                time = first.timestampMillis
            )
            val pending = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val stored = if (PermissionManager.has(Manifest.permission.READ_SMS)) {
                        withTimeoutOrNull(2_000) {
                            var match: Data? = null
                            while (match == null) {
                                match = readAfter(data.time).find {
                                    it.phone == data.phone && it.content == data.content
                                }
                                if (match == null) delay(100)
                            }
                            match
                        }
                    } else null
                    withTimeoutOrNull(1_000) { _receiveFlow.emit(stored ?: data) }
                } finally {
                    pending.finish()
                }
            }
        }
    }

    /**
     * 读取最新一条短信
     * > 需要权限：android.permission.READ_SMS
     * @return Data?
     */
    fun readLatest(): Data? {
        try {
            ctx.contentResolver.query(
                inboxUri, projection, null, null,
                "date desc limit 1"
            )?.use { c ->
                if (c.moveToFirst()) {
                    return c.getData()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    /**
     * 读取最近N条短信
     * > 需要权限：android.permission.READ_SMS
     * @param count Int
     * @return List<Data>
     */
    fun readLatest(count: Int): List<Data> {
        if (count <= 0) return listOf()
        try {
            ctx.contentResolver.query(
                inboxUri, projection, null, null,
                "date desc limit $count"
            )?.use { c ->
                val list = mutableListOf<Data>()
                while (c.moveToNext()) {
                    list.add(c.getData())
                }
                return list
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return listOf()
    }

    /**
     * 读取指定时间以后的全部消息
     * > 需要权限：android.permission.READ_SMS
     * @param timestamp Long 时间戳，单位毫秒，获取的是大于等于这个时间的短信
     * @return List<Data>
     */
    fun readAfter(timestamp: Long): List<Data> {
        try {
            ctx.contentResolver.query(
                inboxUri, projection,
                "( date >= $timestamp )", null, "date asc"
            )?.use { c ->
                val list = mutableListOf<Data>()
                while (c.moveToNext()) {
                    list.add(c.getData())
                }
                return list
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return listOf()
    }

    /**
     * 从Cursor中读取数据
     * @receiver Cursor
     * @return Data
     */
    private fun Cursor.getData(): Data {
        return Data().apply {
            id = getString(getColumnIndex("_id").coerceAtLeast(0))
            subId = getLongOrNull(getColumnIndex("sub_id")) ?: -1
            content = getString(getColumnIndex("body").coerceAtLeast(0))
            phone = getString(getColumnIndex("address").coerceAtLeast(0))
            time = getString(getColumnIndex("date").coerceAtLeast(0)).toLongOrNull() ?: 0
        }
    }

    /**
     * 发送文本短信
     * > 需要权限：android.permission.SEND_SMS、android.permission.READ_PHONE_STATE
     * > 发送失败会抛出对应异常。
     * @param desAddress String 目标号码
     * @param scAddress String? 短信中心号码，默认为null
     * @param content String 短信内容
     * @param overtime Long 超时时间，默认为60秒
     * @param use SmsManager? 使用的短信管理器，相当于指定发送卡槽，不填则使用默认的
     */
    suspend fun sendText(
        desAddress: String,
        scAddress: String? = null,
        content: String,
        overtime: Long = 60 * 1000,
        use: SmsManager? = null
    ) {
        require(overtime > 0) { "Timeout must be positive" }
        // 判断是否具备发送短信的权限
        if (PermissionManager.has(
                arrayOf(
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.READ_PHONE_STATE
                )
            ).not()
        ) {
            throw Exception("缺少发送短信的权限！")
        }
        // 获取短信管理器
        val smsManager = use ?: getDefaultSmsManager()
        val token = UUID.randomUUID().toString()
        val sent = CompletableDeferred<Boolean>()
        val delivered = CompletableDeferred<Boolean>()
        val receivers = mutableListOf<BroadcastReceiver>()
        val intents = mutableListOf<PendingIntent>()
        try {
            val sentAction = "${ctx.packageName}.SMS_SENT.$token"
            val deliveredAction = "${ctx.packageName}.SMS_DELIVERED.$token"
            receivers += registerResult(sentAction, sent, false)
            receivers += registerResult(deliveredAction, delivered, true)
            fun callback(action: String) = PendingIntent.getBroadcast(
                ctx, 0, Intent(action).setPackage(ctx.packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ).also { intents += it }
            smsManager.sendTextMessage(
                desAddress, scAddress, content, callback(sentAction), callback(deliveredAction)
            )
            var sentSuccessfully = false
            val deliveredSuccessfully = withTimeoutOrNull(overtime) {
                sentSuccessfully = sent.await()
                if (sentSuccessfully) delivered.await() else false
            }
            if (!sentSuccessfully) throw Exception("发送短信失败！")
            if (deliveredSuccessfully != true) throw Exception("目标用户未成功接收短信！")
        } finally {
            receivers.forEach { ctx.unregisterReceiver(it) }
            intents.forEach { it.cancel() }
            sent.cancel()
            delivered.cancel()
        }
    }

    internal fun registerResult(
        action: String,
        result: CompletableDeferred<Boolean>,
        delivery: Boolean
    ): BroadcastReceiver {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                result.complete(delivery || resultCode == Activity.RESULT_OK)
            }
        }
        ContextCompat.registerReceiver(ctx, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
        return receiver
    }

    /**
     * 获取默认的短信管理器
     * @return SmsManager
     */
    private fun getDefaultSmsManager(): SmsManager {
        val defSubId = SubscriptionManager.getDefaultSmsSubscriptionId()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ctx.getSystemService(SmsManager::class.java).createForSubscriptionId(defSubId)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }
    }

    /**
     * 通过指定卡槽获取短信管理器
     * > 需要权限：android.permission.READ_PHONE_STATE
     * @param slot Int 卡槽
     * @return SmsManager
     */
    @SuppressLint("MissingPermission")
    fun getSmsManager(slot: Int): SmsManager {
        if (slot < 0) return getDefaultSmsManager()
        val subId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            SubscriptionManager.getSubscriptionId(slot)
        } else {
            ctx.getSystemService(SubscriptionManager::class.java)
                .getActiveSubscriptionInfoForSimSlotIndex(slot)?.subscriptionId
        }
        if (subId == null) return getDefaultSmsManager()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ctx.getSystemService(SmsManager::class.java).createForSubscriptionId(subId)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getSmsManagerForSubscriptionId(subId)
        }
    }

}
