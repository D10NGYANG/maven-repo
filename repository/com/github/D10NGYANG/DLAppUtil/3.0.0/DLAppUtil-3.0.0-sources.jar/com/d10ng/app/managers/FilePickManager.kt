package com.d10ng.app.managers

import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** 文件选择器；取消或复制失败返回 null。 */
object FilePickManager {
    private val requests = ActivityResultRequests(ActivityResultContracts.OpenDocument())

    internal fun onComponentActivityCreated(act: ComponentActivity) = requests.register(act)
    internal fun onComponentActivityDestroyed(act: ComponentActivity) = requests.unregister(act)

    suspend fun pick(array: Array<String> = arrayOf("application/octet-stream", "*/*")): String? {
        val uri = requests.request(array) ?: return null
        return copyPickedFile(uri)
    }
}
