package com.d10ng.app.managers

import android.net.Uri
import android.provider.OpenableColumns
import com.d10ng.app.startup.ctx
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File

internal suspend fun copyPickedFile(uri: Uri): String? {
    var file: File? = null
    return try {
        withContext(Dispatchers.IO) { copyPickedFileOnIo(uri) { file = it } }
    } catch (e: CancellationException) {
        file?.delete()
        throw e
    }
}

private suspend fun copyPickedFileOnIo(uri: Uri, onCreated: (File) -> Unit): String? {
    var file: File? = null
    var complete = false
    return try {
        val name = ctx.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { cursor ->
            val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (column >= 0 && cursor.moveToFirst()) cursor.getString(column) else null
        }
        val extension = name?.substringAfterLast('.', "")
            ?.takeIf { it.length in 1..10 && it.all { char -> char.isLetterOrDigit() } }
        val input = ctx.contentResolver.openInputStream(uri) ?: return null
        input.use {
            val target = File.createTempFile("picked-", ".${extension ?: "tmp"}", ctx.cacheDir)
            file = target
            onCreated(target)
            target.outputStream().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (true) {
                    kotlin.coroutines.coroutineContext.ensureActive()
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                }
            }
        }
        kotlin.coroutines.coroutineContext.ensureActive()
        complete = true
        file?.absolutePath
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        null
    } finally {
        if (!complete) file?.delete()
    }
}
