package com.d10ng.mapbox.view

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.d10ng.app.resource.getResDrawable
import com.d10ng.app.resource.toBitmap
import com.d10ng.compose.ui.AppText
import com.d10ng.mapbox.R
import com.d10ng.mapbox.stores.MapViewStore
import com.mapbox.geojson.Point
import com.mapbox.maps.extension.style.layers.properties.generated.IconAnchor
import com.mapbox.maps.plugin.annotation.generated.PointAnnotationOptions

/**
 * 位置确认视图
 * @Author d10ng
 * @Date 2023/9/16 15:37
 */

private const val TARGET = "TARGET"

@Composable
fun LocationConfirmView(
    label: String,
    description: String,
    point: Point
) {
    Text(
        text = label,
        style = AppText.Normal.Title.default,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.fillMaxWidth()
    )
    Text(
        text = description,
        style = AppText.Normal.Tips.mini,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
    )
    val pointOptions = remember(point) {
        mapOf(
            1 to PointAnnotationOptions()
                .withGeometry(point)
                .withIconImage(TARGET)
                .withIconSize(1.2)
                .withIconAnchor(IconAnchor.BOTTOM)
        )
    }
    var zoom by remember(point) { mutableStateOf(MapViewStore.zoomFlow.value) }
    val height = with(LocalDensity.current) { (LocalWindowInfo.current.containerSize.height / 4).toDp() }
    MapboxView(
        modifier = Modifier
            .padding(vertical = 16.dp)
            .fillMaxWidth()
            .height(height),
        layer = MapViewStore.getCurrentLayer(),
        cameraZoom = zoom,
        cameraTarget = point,
        onCameraZoomChange = { zoom = it },
        onCameraCenterChange = {},
        onStyleLoad = { style ->
            getResDrawable(R.drawable.ic_map_location_target_25)?.apply {
                style.addImage(TARGET, this.toBitmap())
            }
        },
        pointOptions = pointOptions
    )
}
