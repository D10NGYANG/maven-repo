package com.d10ng.datastore.processor

import com.google.devtools.ksp.getDeclaredProperties
import com.google.devtools.ksp.processing.CodeGenerator
import com.google.devtools.ksp.processing.Dependencies
import com.google.devtools.ksp.processing.KSPLogger
import com.google.devtools.ksp.symbol.ClassKind
import com.google.devtools.ksp.symbol.KSAnnotated
import com.google.devtools.ksp.symbol.KSClassDeclaration
import com.google.devtools.ksp.symbol.KSType
import com.google.devtools.ksp.symbol.KSVisitorVoid
import com.google.devtools.ksp.symbol.Modifier
import com.google.devtools.ksp.symbol.Nullability
import com.google.devtools.ksp.symbol.Variance
import java.util.Locale

class PreferenceDataStoreVisitor(
    private val codeGenerator: CodeGenerator,
    private val logger: KSPLogger,
    private val options: Map<String, String>
) : KSVisitorVoid() {
    override fun visitClassDeclaration(classDeclaration: KSClassDeclaration, data: Unit) {
        val packageName = classDeclaration.packageName.asString()
        val className = classDeclaration.simpleName.asString()
        val fileName = "${className}Store"
        val name = (classDeclaration.preferenceAnnotation("PreferenceDataStore")
            ?.arguments?.find { it.name?.asString() == "name" }?.value as? String)
            .orEmpty().ifEmpty { className }
        val properties = classDeclaration.getDeclaredProperties()
            .filter { it.preferenceAnnotation("PreferenceKey") != null }.toList()
        val imports = mutableSetOf<String>()
        val methods = StringBuilder()

        for (property in properties) {
            try {
                val type = property.type.resolve()
                require(type.nullability != Nullability.NULLABLE) { "Nullable preference values are not supported" }
                val declaration = type.declaration as? KSClassDeclaration
                val isEnum = declaration?.classKind == ClassKind.ENUM_CLASS
                val isDataClass = declaration?.modifiers?.contains(Modifier.DATA) == true
                if (isDataClass) {
                    require(declaration!!.annotations.any {
                        it.annotationType.resolve().declaration.qualifiedName?.asString() == "kotlinx.serialization.Serializable"
                    }) { "Data class must have @Serializable" }
                }
                val typeName = type.renderType()
                val keyFactory = when (typeName) {
                    "kotlin.String" -> "stringPreferencesKey"
                    "kotlin.Int" -> "intPreferencesKey"
                    "kotlin.Long" -> "longPreferencesKey"
                    "kotlin.Float" -> "floatPreferencesKey"
                    "kotlin.Double" -> "doublePreferencesKey"
                    "kotlin.Boolean" -> "booleanPreferencesKey"
                    "kotlin.collections.Set<kotlin.String>" -> "stringSetPreferencesKey"
                    else -> {
                        require(isEnum || isDataClass) { "Unsupported preference type: $typeName" }
                        "stringPreferencesKey"
                    }
                }
                type.collectImports(imports)
                val annotation = property.preferenceAnnotation("PreferenceKey")!!
                val keys = (annotation.arguments.find { it.name?.asString() == "keys" }?.value as? List<*>)
                    .orEmpty().map { it as KSType }
                val getParams = keys.mapIndexed { index, keyType ->
                    "key$index: ${keyType.renderType()}"
                }.joinToString(", ")
                val getArgs = keys.indices.joinToString(", ") { "key$it" }
                val setParams = listOf(getParams, "value: $typeName").filter { it.isNotEmpty() }.joinToString(", ")
                val setArgs = listOf(getArgs, "value").filter { it.isNotEmpty() }.joinToString(", ")
                val propertyName = property.simpleName.asString()
                val keyName = if (keys.isEmpty()) propertyName.quoted()
                    else "preferenceKey(${propertyName.quoted()}, $getArgs)"
                val funName = propertyName.replaceFirstChar {
                    if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString()
                }
                val decode = when {
                    isEnum -> "?.let { s -> $typeName.valueOf(s) }"
                    isDataClass -> "?.let { s -> json.decodeFromString<$typeName>(s) }"
                    else -> ""
                }
                val encode = when {
                    isEnum -> "value.name"
                    isDataClass -> "json.encodeToString(value)"
                    else -> "value"
                }
                val default = (annotation.arguments.find { it.name?.asString() == "default" }?.value as? String)
                    .orEmpty().let { if (it.isEmpty()) "" else " ?: $it" }
                methods.append("\topen fun `get${funName}Flow`($getParams) = dataStore.data.map { it[$keyFactory($keyName)]$decode$default }\n")
                methods.append("\topen suspend fun `get$funName`($getParams) = `get${funName}Flow`($getArgs).first()\n")
                methods.append("\topen fun `get${funName}Sync`($getParams) = runBlocking { `get$funName`($getArgs) }\n")
                methods.append("\topen suspend fun `set$funName`($setParams) = dataStore.edit { it[$keyFactory($keyName)] = $encode }\n")
                methods.append("\topen fun `set${funName}Sync`($setParams) = runBlocking { `set$funName`($setArgs) }\n\n")
            } catch (error: IllegalArgumentException) {
                logger.error("${property.simpleName.asString()}: ${error.message}", property)
                return
            }
        }

        val source = buildString {
            if (packageName.isNotEmpty()) append("package $packageName\n\n")
            append("import androidx.datastore.preferences.core.*\n")
            append("import com.d10ng.datastore.DataStoreOwner\n")
            append("import kotlinx.coroutines.flow.*\nimport kotlinx.coroutines.*\n")
            append("import kotlinx.serialization.encodeToString\n")
            // Preserve simple type names in existing default expressions without conflicting imports.
            imports.groupBy { it.substringAfterLast('.') }.values.filter { it.size == 1 }
                .forEach { append("import ${it.single()}\n") }
            append("\nopen class $fileName : DataStoreOwner(${name.quoted()}) {\n\n")
            append("\tcompanion object {\n\t\tval instant by lazy { $fileName() }\n\t}\n\n")
            append(methods)
            append("}\n")
        }
        codeGenerator.createNewFile(
            Dependencies(false, classDeclaration.containingFile!!), packageName, fileName
        ).use { it.write(source.toByteArray()) }
    }

    private fun KSAnnotated.preferenceAnnotation(name: String) = annotations.find {
        it.annotationType.resolve().declaration.qualifiedName?.asString() == "com.d10ng.datastore.annotation.$name"
    }

    private fun KSType.renderType(): String {
        require(!isError && declaration is KSClassDeclaration) { "Unresolved or unsupported type: $this" }
        val name = requireNotNull(declaration.qualifiedName?.asString()) { "Local types are not supported: $this" }
        val parameters = if (arguments.isEmpty()) "" else arguments.joinToString(", ", "<", ">") { argument ->
            require(argument.variance != Variance.STAR) { "Star projections are not supported: $this" }
            val variance = when (argument.variance) {
                Variance.COVARIANT -> "out "
                Variance.CONTRAVARIANT -> "in "
                else -> ""
            }
            variance + requireNotNull(argument.type).resolve().renderType()
        }
        return name + parameters + if (nullability == Nullability.NULLABLE) "?" else ""
    }

    private fun KSType.collectImports(imports: MutableSet<String>) {
        generateSequence(declaration) { it.parentDeclaration }
            .filterIsInstance<KSClassDeclaration>()
            .mapNotNull { it.qualifiedName?.asString() }
            .filterNot { it.startsWith("kotlin.") }
            .forEach(imports::add)
        arguments.forEach { it.type?.resolve()?.collectImports(imports) }
    }

    private fun String.quoted() = "\"" + replace("\\", "\\\\").replace("\"", "\\\"")
        .replace("$", "\\$").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t") + "\""
}
