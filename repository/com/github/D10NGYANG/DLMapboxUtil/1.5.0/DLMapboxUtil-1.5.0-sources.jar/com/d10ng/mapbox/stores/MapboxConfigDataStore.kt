package com.d10ng.mapbox.stores

import androidx.datastore.preferences.core.*
import com.d10ng.datastore.DataStoreOwner
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.*
import kotlinx.serialization.encodeToString
import com.d10ng.mapbox.constant.MapLayerType

open class MapboxConfigDataStore : DataStoreOwner("mapbox_config.preferences_pb") {

	companion object {
		val instant by lazy { MapboxConfigDataStore() }
	}

	open fun getLayerFlow() = dataStore.data.map { it[stringPreferencesKey("layer")]?.let { s -> MapLayerType.valueOf(s) } }
	open suspend fun getLayer() = getLayerFlow().first()
	open fun getLayerSync() = runBlocking { getLayer() }
	open suspend fun setLayer(value: MapLayerType) = dataStore.edit { it[stringPreferencesKey("layer")] = value.toString() }
	open fun setLayerSync(value: MapLayerType) = runBlocking { setLayer(value) }

	open fun getHistoryFlow() = dataStore.data.map { it[stringSetPreferencesKey("history")] }
	open suspend fun getHistory() = getHistoryFlow().first()
	open fun getHistorySync() = runBlocking { getHistory() }
	open suspend fun setHistory(value: Set<String>) = dataStore.edit { it[stringSetPreferencesKey("history")] = value }
	open fun setHistorySync(value: Set<String>) = runBlocking { setHistory(value) }

	open fun getNavigationTargetFlow() = dataStore.data.map { it[stringPreferencesKey("navigationTarget")] }
	open suspend fun getNavigationTarget() = getNavigationTargetFlow().first()
	open fun getNavigationTargetSync() = runBlocking { getNavigationTarget() }
	open suspend fun setNavigationTarget(value: String) = dataStore.edit { it[stringPreferencesKey("navigationTarget")] = value }
	open fun setNavigationTargetSync(value: String) = runBlocking { setNavigationTarget(value) }

}