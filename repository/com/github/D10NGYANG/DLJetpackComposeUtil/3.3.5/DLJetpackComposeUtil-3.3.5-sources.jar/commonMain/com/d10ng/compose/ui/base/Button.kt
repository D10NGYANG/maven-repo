package com.d10ng.compose.ui.base

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.d10ng.compose.ui.AppColor
import com.d10ng.compose.ui.AppShape
import com.d10ng.compose.ui.AppText
import com.d10ng.compose.utils.isDark
import com.d10ng.compose.utils.next

/**
 * 按钮组件
 * @Author d10ng
 * @Date 2023/9/4 10:07
 */

/**
 * 按钮类型
 * 通过不同类型控制按钮的主色调与边框颜色
 */
enum class ButtonType(val color: Color, val border: Color) {
    // 默认（白色背景，灰色边框）
    DEFAULT(Color.White, AppColor.Neutral.border),
    // 主要（品牌主色）
    PRIMARY(AppColor.Main.primary, AppColor.Main.primary),
    // 成功（绿色）
    SUCCESS(AppColor.Func.success, AppColor.Func.success),
    // 警告（橙色）
    WARNING(AppColor.Func.assist, AppColor.Func.assist),
    // 危险（红色）
    DANGER(AppColor.Func.error, AppColor.Func.error),
}

/**
 * 按钮尺寸
 * 通过不同尺寸控制按钮的字体大小、内边距及高度
 */
enum class ButtonSize(val textSize: TextUnit, val paddingValues: PaddingValues, val height: Dp) {
    // 普通（默认尺寸）
    NORMAL(AppText.Normal.Title.default.fontSize, ButtonDefaults.ContentPadding, 40.dp),
    // 迷你（最小尺寸）
    MINI(AppText.Normal.Title.mini.fontSize, PaddingValues(6.dp, 2.dp), 28.dp),
    // 小
    SMALL(AppText.Normal.Title.small.fontSize, PaddingValues(12.dp, 4.dp), 36.dp),
    // 中大
    BIG(AppText.Normal.Title.big.fontSize, PaddingValues(21.dp, 7.dp), 44.dp),
    // 大（最大尺寸）
    LARGE(AppText.Normal.Title.large.fontSize, PaddingValues(36.dp, 12.dp), 64.dp),
}

/**
 * 按钮
 * @param text String 按钮文字
 * @param modifier Modifier 修饰符
 * @param icon @Composable (() -> Unit)? 按钮左侧图标，为 null 时不显示
 * @param type ButtonType 按钮类型，控制主色调，默认为 [ButtonType.DEFAULT]
 * @param size ButtonSize 按钮尺寸，默认为 [ButtonSize.NORMAL]
 * @param plain Boolean 是否为朴素按钮（白色背景、有色边框和文字），默认 false
 * @param hairline Boolean 是否使用细边框（0.3.dp），默认 false 使用 1.dp 边框
 * @param disabled Boolean 是否禁用按钮，禁用时颜色变浅且不响应点击，默认 false
 * @param loading Boolean 是否显示加载状态，加载时显示 loading 图标且不响应点击，默认 false
 * @param shape RoundedCornerShape 按钮形状，默认为 [AppShape.RC.v4]
 * @param color Color? 自定义按钮颜色，设置后将覆盖 [type] 中定义的颜色，默认 null
 * @param onClick Function0<Unit> 点击事件回调
 */
@Composable
fun Button(
    text: String,
    modifier: Modifier = Modifier,
    icon: @Composable (() -> Unit)? = null,
    type: ButtonType = ButtonType.DEFAULT,
    size: ButtonSize = ButtonSize.NORMAL,
    plain: Boolean = false,
    hairline: Boolean = false,
    disabled: Boolean = false,
    loading: Boolean = false,
    shape: RoundedCornerShape = AppShape.RC.v4,
    color: Color? = null,
    onClick: () -> Unit
) {
    val enabled = !disabled && !loading
    // 主要颜色
    val mainColor = color ?: type.color
    // 背景颜色
    val bgColor = if (plain) Color.White else mainColor
    // 内容颜色
    val contentColor = if (plain) {
        if (mainColor.isDark()) mainColor else AppColor.Neutral.title
    } else if (mainColor.isDark()) Color.White else AppColor.Neutral.title
    // 边框颜色
    val borderColor = color ?: type.border
    val sizedModifier = if (size == ButtonSize.MINI || size == ButtonSize.SMALL) {
        modifier.height(size.height)
    } else {
        modifier
    }
    val stateModifier = if (loading) {
        sizedModifier.semantics {
            contentDescription = text
            stateDescription = "加载中"
        }
    } else {
        sizedModifier
    }
    Button(
        onClick = onClick,
        modifier = stateModifier,
        enabled = enabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = bgColor,
            disabledContainerColor = if (loading) bgColor else bgColor.next(0.5),
            contentColor = contentColor,
            disabledContentColor = if (loading) contentColor else contentColor.next(0.5),
        ),
        border = BorderStroke(
            width = if (hairline) 0.3.dp else 1.dp,
            color = if (disabled) borderColor.next(0.5) else borderColor
        ),
        contentPadding = size.paddingValues
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(14.dp),
                color = contentColor,
                strokeWidth = 2.dp,
                strokeCap = StrokeCap.Round
            )
        } else {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(text = text, fontSize = size.textSize)
        }
    }
}

@Preview
@Composable
fun PreviewButton() {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 按钮类型
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(text = "默认", onClick = {})
            Button(text = "主要", type = ButtonType.PRIMARY, onClick = {})
            Button(text = "成功", type = ButtonType.SUCCESS, onClick = {})
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(text = "警告", type = ButtonType.WARNING, onClick = {})
            Button(text = "危险", type = ButtonType.DANGER, onClick = {})
        }
        // 朴素按钮
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(text = "朴素", type = ButtonType.PRIMARY, plain = true, onClick = {})
            Button(text = "禁用", type = ButtonType.PRIMARY, disabled = true, onClick = {})
            Button(text = "加载中", type = ButtonType.PRIMARY, loading = true, onClick = {})
        }
        // 按钮尺寸
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(text = "迷你", type = ButtonType.PRIMARY, size = ButtonSize.MINI, onClick = {})
            Button(text = "小", type = ButtonType.PRIMARY, size = ButtonSize.SMALL, onClick = {})
            Button(text = "普通", type = ButtonType.PRIMARY, size = ButtonSize.NORMAL, onClick = {})
            Button(text = "大", type = ButtonType.PRIMARY, size = ButtonSize.BIG, onClick = {})
        }
    }
}
