package com.d10ng.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.d10ng.app.managers.ActivityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import java.lang.ref.WeakReference

/**
 * 手持机机身按键监听服务
 * @Author d10ng
 * @Date 2023/11/10 14:27
 */
class PhysicalButtonAccessibilityService : AccessibilityService() {
    companion object {
        var instant: WeakReference<PhysicalButtonAccessibilityService?> = WeakReference(null)

        /**
         * 是否开启了无障碍服务
         * @return Boolean
         */
        fun isEnable(): Boolean {
            return instant.get() != null
        }

        /**
         * 开启无障碍服务
         */
        fun start() {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            ActivityManager.top()?.startActivity(intent)
        }

        // 长按时间
        private const val LONG_PRESS_TIME = 2500L

        // 单击按键事件
        private val clickEvent = MutableSharedFlow<Int>()
        val clickEventFlow = clickEvent.asSharedFlow()

        // 长按按键事件
        private val longPressEvent = MutableSharedFlow<Int>()
        val longPressEventFlow = longPressEvent.asSharedFlow()

    }

    private val scope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())
    private val presses = mutableMapOf<Int, Job>()
    private val longPressed = mutableSetOf<Int>()

    private fun onKeyDown(event: KeyEvent) {
        val keyCode = event.keyCode
        if (event.repeatCount != 0 || presses.containsKey(keyCode)) return
        presses[keyCode] = scope.launch {
            delay(LONG_PRESS_TIME)
            longPressed += keyCode
            scope.launch { longPressEvent.emit(keyCode) }
        }
    }

    private fun onKeyUp(keyCode: Int) {
        val job = presses.remove(keyCode) ?: return
        val wasLongPress = longPressed.remove(keyCode)
        job.cancel()
        if (!wasLongPress) scope.launch { clickEvent.emit(keyCode) }
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        event ?: return super.onKeyEvent(null)
        when (event.action) {
            KeyEvent.ACTION_DOWN -> onKeyDown(event)
            KeyEvent.ACTION_UP -> onKeyUp(event.keyCode)
        }
        return super.onKeyEvent(event)
    }

    override fun onCreate() {
        super.onCreate()
        instant = WeakReference(this)
    }

    override fun onDestroy() {
        scope.cancel()
        presses.clear()
        longPressed.clear()
        instant = WeakReference(null)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    }

    override fun onInterrupt() {
    }
}