package com.d10ng.datastore

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.atomicfu.locks.synchronized
import kotlinx.serialization.json.Json
import okio.Path
import okio.Path.Companion.toPath

internal expect fun createDataStoreByName(name: String): DataStore<Preferences>

private val storesLock = SynchronizedObject()
// One application-lifetime instance per file; cancelling it would invalidate other owners.
private val stores = mutableMapOf<Path, DataStore<Preferences>>()

internal fun createDataStore(producePath: () -> String): DataStore<Preferences> {
    val path = producePath().toPath(normalize = true)
    return synchronized(storesLock) {
        stores.getOrPut(path) {
            PreferenceDataStoreFactory.createWithPath(produceFile = { path })
        }
    }
}

open class DataStoreOwner(name: String) : IDataStoreOwner {
    override val dataStore: DataStore<Preferences> by lazy {
        val fileName = if (name.endsWith(".preferences_pb")) name else "${name}.preferences_pb"
        createDataStoreByName(fileName)
    }

    /** Keeps unambiguous legacy keys; ambiguous tuples use a separate, length-prefixed namespace. */
    protected fun preferenceKey(name: String, vararg keys: Any): String {
        val parts = keys.map { it.toString() }
        if (parts.size <= 1 || parts.none { ':' in it }) {
            return (listOf(name) + parts).joinToString(":")
        }
        return "\u0000DLDatastore:v2:${name.length}:$name:" +
            parts.joinToString("") { "${it.length}:$it" }
    }

    val json = IDataStoreOwner.json
}

interface IDataStoreOwner {
    val dataStore: DataStore<Preferences>

    companion object {

        /** 自定义规则的JSON工具 */
        val json by lazy {
            Json {
                // 忽略JSON字符串里有但data class中没有的key
                ignoreUnknownKeys = true
                // 如果接收到的JSON字符串的value为null，但是data class中的对应属性不能为null，那就使用属性的默认值
                coerceInputValues = true
                // 如果创建data class实例时有些属性没有赋值，那就使用默认值进行转换成JSON字符串
                encodeDefaults = true
                // 属性放宽
                isLenient = true
            }
        }
    }
}