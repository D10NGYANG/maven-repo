package com.d10ng.app.managers

import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContract
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** One in-flight result per Activity/launcher; all access stays on the main thread. */
internal class ActivityResultRequests<I, O>(private val contract: ActivityResultContract<I, O>) {
    private class Entry<I, O> {
        lateinit var launcher: ActivityResultLauncher<I>
        var pending: CompletableDeferred<O>? = null
    }

    private val entries = mutableMapOf<ComponentActivity, Entry<I, O>>()

    fun register(activity: ComponentActivity) {
        if (entries.containsKey(activity)) return
        val entry = Entry<I, O>()
        entry.launcher = activity.registerForActivityResult(contract) { result ->
            val pending = entry.pending
            entry.pending = null
            pending?.complete(result)
        }
        entries[activity] = entry
    }

    fun unregister(activity: ComponentActivity) {
        entries.remove(activity)?.let {
            val pending = it.pending
            it.pending = null
            it.launcher.unregister()
            pending?.cancel()
        }
    }

    suspend fun request(input: I): O? = withContext(Dispatchers.Main.immediate) {
        val activity = ActivityManager.top()
        val entry = entries[activity] ?: return@withContext null
        while (entry.pending != null) entry.pending?.join()
        if (entries[activity] !== entry) return@withContext null
        val pending = CompletableDeferred<O>()
        entry.pending = pending
        try {
            entry.launcher.launch(input)
        } catch (e: Exception) {
            entry.pending = null
            pending.cancel()
            throw e
        }
        // Caller cancellation does not free the launcher before its late result arrives.
        pending.await()
    }
}
