@file:OptIn(kotlinx.cinterop.ExperimentalForeignApi::class)

package com.d10ng.crypto

import kotlinx.cinterop.*
import platform.CoreFoundation.*
import platform.Security.*

// Create/Copy 引用由当前作用域统一释放，包括异常路径；每个数据块使用独立作用域。
private class CFResources {
    private val refs = mutableListOf<CFTypeRef>()
    fun <T : CPointed> own(value: CPointer<T>?): CPointer<T> =
        requireNotNull(value) { "Security framework operation failed" }.also { refs.add(it) }
    fun close() { refs.asReversed().forEach { CFRelease(it) } }
    fun data(bytes: ByteArray): CFDataRef = bytes.usePinned {
        own(CFDataCreate(null, if (bytes.isEmpty()) null else it.addressOf(0).reinterpret(), bytes.size.toLong()))
    }
    fun attributes(privateKey: Boolean): CFMutableDictionaryRef {
        val dict = own(CFDictionaryCreateMutable(null, 0, null, null))
        CFDictionaryAddValue(dict, kSecAttrKeyType, kSecAttrKeyTypeRSA)
        CFDictionaryAddValue(dict, kSecAttrKeyClass, if (privateKey) kSecAttrKeyClassPrivate else kSecAttrKeyClassPublic)
        return dict
    }
}

private inline fun <T> withCF(block: CFResources.() -> T): T {
    val resources = CFResources()
    return try { resources.block() } finally { resources.close() }
}

private fun CFDataRef.bytes(): ByteArray {
    val length = CFDataGetLength(this)
    require(length in 0..Int.MAX_VALUE.toLong()) { "RSA data too large" }
    return if (length == 0L) byteArrayOf() else requireNotNull(CFDataGetBytePtr(this)).readBytes(length.toInt())
}

actual fun generateRSAKeyPair(keyFormat: KeyFormat, keyLength: Int): Array<String> = withCF {
    val dict = attributes(true)
    val size = memScoped { own(CFNumberCreate(null, kCFNumberSInt32Type, alloc<IntVar>().apply { value = keyLength }.ptr)) }
    CFDictionaryAddValue(dict, kSecAttrKeySizeInBits, size)
    val privateKey = own(SecKeyCreateRandomKey(dict, null))
    val publicKey = own(SecKeyCopyPublicKey(privateKey))
    val publicBytes = own(SecKeyCopyExternalRepresentation(publicKey, null)).bytes()
    val privateBytes = own(SecKeyCopyExternalRepresentation(privateKey, null)).bytes()
    arrayOf(
        (if (keyFormat == KeyFormat.PKCS8) wrapRSAKey(publicBytes, true) else publicBytes).encodeBase64ToString(),
        (if (keyFormat == KeyFormat.PKCS8) wrapRSAKey(privateBytes, false) else privateBytes).encodeBase64ToString()
    )
}

private fun algorithm(fillMode: RSAFillMode, hash: HashAlgorithm?, mgf: MGFHashAlgorithm?): SecKeyAlgorithm? =
    when (fillMode) {
        RSAFillMode.PKCS1Padding -> kSecKeyAlgorithmRSAEncryptionPKCS1
        RSAFillMode.NoPadding -> kSecKeyAlgorithmRSAEncryptionRaw
        RSAFillMode.OAEP -> {
            requireNotNull(hash) { "OAEP requires a hash" }
            requireNotNull(mgf) { "OAEP requires an MGF hash" }
            require(hash.name == mgf.name) { "iOS requires the OAEP and MGF1 hashes to match" }
            when (hash) {
                HashAlgorithm.SHA1 -> kSecKeyAlgorithmRSAEncryptionOAEPSHA1
                HashAlgorithm.SHA256 -> kSecKeyAlgorithmRSAEncryptionOAEPSHA256
            }
        }
    }

actual fun rsaPublicEncrypt(
    data: String,
    publicKey: String,
    encryptMode: RSAEncryptMode,
    fillMode: RSAFillMode,
    hashAlgorithm: HashAlgorithm?,
    mgfHashAlgorithm: MGFHashAlgorithm?
): String = withCF {
    val keyBytes = unwrapRSAKey(cleanRSAKey(publicKey).decodeBase64ToByteArray(), true)
    val key = own(SecKeyCreateWithData(data(keyBytes), attributes(false), null))
    val algorithm = algorithm(fillMode, hashAlgorithm, mgfHashAlgorithm)
    require(SecKeyIsAlgorithmSupported(key, kSecKeyOperationTypeEncrypt, algorithm)) { "Unsupported RSA configuration" }
    val size = rsaBlockSize(SecKeyGetBlockSize(key).toInt(), fillMode, hashAlgorithm)
    val input = data.encodeToByteArray()
    validateRSAInput(input.size, size, fillMode == RSAFillMode.NoPadding)
    val blocks = mutableListOf<ByteArray>()
    var offset = 0
    while (offset < input.size) {
        val end = minOf(offset.toLong() + size, input.size.toLong()).toInt()
        blocks.add(withCF { own(SecKeyCreateEncryptedData(key, algorithm, data(input.copyOfRange(offset, end)), null)).bytes() })
        offset = end
    }
    joinRSABytes(blocks).encodeBase64ToString()
}

actual fun rsaPrivateDecrypt(
    data: String,
    privateKey: String,
    encryptMode: RSAEncryptMode,
    fillMode: RSAFillMode,
    hashAlgorithm: HashAlgorithm?,
    mgfHashAlgorithm: MGFHashAlgorithm?
): String = withCF {
    val keyBytes = unwrapRSAKey(cleanRSAKey(privateKey).decodeBase64ToByteArray(), false)
    val key = own(SecKeyCreateWithData(data(keyBytes), attributes(true), null))
    val algorithm = algorithm(fillMode, hashAlgorithm, mgfHashAlgorithm)
    require(SecKeyIsAlgorithmSupported(key, kSecKeyOperationTypeDecrypt, algorithm)) { "Unsupported RSA configuration" }
    val size = SecKeyGetBlockSize(key).toInt()
    val input = decodeRSACiphertext(data)
    validateRSAInput(input.size, size, true)
    val blocks = mutableListOf<ByteArray>()
    var offset = 0
    while (offset < input.size) {
        val end = offset + size
        blocks.add(withCF { own(SecKeyCreateDecryptedData(key, algorithm, data(input.copyOfRange(offset, end)), null)).bytes() })
        offset = end
    }
    joinRSABytes(blocks).decodeToString()
}
