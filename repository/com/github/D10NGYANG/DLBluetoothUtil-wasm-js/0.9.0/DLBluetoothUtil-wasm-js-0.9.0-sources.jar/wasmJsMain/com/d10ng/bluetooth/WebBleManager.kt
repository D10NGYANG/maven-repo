package com.d10ng.bluetooth

import com.d10ng.bluetooth.constant.BleDevice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.await
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

/**
 * Web蓝牙管理
 * @Author d10ng
 * @Date 2025/10/14 16:58
 */
@OptIn(ExperimentalWasmJsInterop::class)
object WebBleManager: ABleManager() {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // 想要访问的服务UUID列表
    private val optionalServices = mutableSetOf(
        "generic_access",
        "generic_attribute",
        "device_information",
        "battery_service"
    )

    init {
        scope.launch {
            if (isSupported()) {
                val available = navigator.bluetooth!!.getAvailability().await<JsBoolean>()
                mutableIsEnabledFlow.value = available.toBoolean()
            }
        }
    }

    override fun isSupported(): Boolean {
        return navigator.bluetooth != null
    }

    override fun isSupportEnable(): Boolean {
        return false
    }

    override suspend fun enable() {
        // 不支持
    }

    /**
     * 增加需要访问的服务
     * @param uuid
     */
    fun addService(uuid: String) {
        optionalServices.add(uuid)
    }

    override fun scan(serviceUuids: List<String>): Flow<BleDevice> = callbackFlow {
        if (!isSupported()) {
            close()
            return@callbackFlow
        }
        val job = launch {
            val options = if (serviceUuids.isEmpty()) {
                createJsBluetoothRequestOptions(true, optionalServices.map { it.toJsString() }.toJsArray())
            } else {
                val allOptional = (optionalServices + serviceUuids).map { it.toJsString() }.toJsArray()
                createJsBluetoothRequestOptionsWithFilters(
                    serviceUuids.map { it.toJsString() }.toJsArray(),
                    allOptional
                )
            }
            val device = runCatching {
                navigator.bluetooth!!.requestDevice(options).await<BluetoothDevice>()
            }.getOrNull()

            if (device != null) {
                trySend(BleDevice(
                    name = device.name ?: "Unknown",
                    address = device.id,
                    rssi = 0,
                    nativeHandle = device
                ))
            }
            close()
        }
        awaitClose { job.cancel() }
    }

    override fun scanByAddress(addresses: List<String>): Flow<BleDevice> = callbackFlow {
        if (!isSupported()) {
            close()
            return@callbackFlow
        }
        val job = launch {
            // 从此 Origin 下曾经授权过的设备中按 ID 过滤
            val allDevices = runCatching {
                navigator.bluetooth!!.getDevices().await<JsArray<BluetoothDevice>>()
            }.getOrNull()
            if (allDevices != null) {
                for (i in 0 until allDevices.length) {
                    val device = allDevices[i] ?: continue
                    if (addresses.contains(device.id)) {
                        trySend(BleDevice(
                            name = device.name ?: "Unknown",
                            address = device.id,
                            rssi = 0,
                            nativeHandle = device
                        ))
                    }
                }
            }
            close()
        }
        awaitClose { job.cancel() }
    }

    @Suppress("UNCHECKED_CAST_TO_EXTERNAL_INTERFACE")
    override suspend fun connect(device: BleDevice): ABleConnection {
        val d = device.nativeHandle as BluetoothDevice
        val gatt = d.gatt.connect().await<BluetoothRemoteGATTServer>()
        return WebBleConnection(device, gatt)
    }
}
