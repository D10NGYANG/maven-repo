package com.d10ng.crypto

import org.bouncycastle.asn1.pkcs.PrivateKeyInfo
import java.security.Key
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import org.bouncycastle.asn1.pkcs.RSAPrivateKey
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo
import org.bouncycastle.crypto.params.RSAKeyParameters
import org.bouncycastle.crypto.util.PublicKeyFactory
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.openssl.PEMParser
import java.security.PublicKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.RSAPrivateKeySpec
import java.security.spec.RSAPublicKeySpec
import java.security.spec.X509EncodedKeySpec
import java.security.spec.MGF1ParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.Cipher
import kotlin.io.encoding.Base64.Default.decode
import kotlin.io.encoding.Base64.Default.encode
import kotlin.io.encoding.ExperimentalEncodingApi

/**
 * 生成RSA密钥对
 * @param keyFormat KeyFormat 密钥格式，默认PKCS1
 * @param keyLength Int 密钥长度，默认2048位，可以根据需要调整，建议2048及以上
 * @return Array<String> 公钥和私钥
 */
@OptIn(ExperimentalEncodingApi::class)
actual fun generateRSAKeyPair(
    keyFormat: KeyFormat,
    keyLength: Int
): Array<String> {
    // 生成密钥对，JDK默认生成PKCS8格式
    val keyPairGenerator = KeyPairGenerator.getInstance("RSA")
    keyPairGenerator.initialize(keyLength)
    val keyPair = keyPairGenerator.generateKeyPair()

    return when (keyFormat) {
        KeyFormat.PKCS8 -> arrayOf(encode(keyPair.public.encoded), encode(keyPair.private.encoded))
        KeyFormat.PKCS1 -> {
            // 通过BC工具转换格式
            // 公钥转换
            val spkInfo = SubjectPublicKeyInfo.getInstance(keyPair.public.encoded)
            val primitive = spkInfo.parsePublicKey()
            val publicKeyPKCS1 = primitive.getEncoded()
            // 私钥转换
            val pkInfo = PrivateKeyInfo.getInstance(keyPair.private.encoded)
            val encode = pkInfo.parsePrivateKey()
            val privateKeyPrimitive = encode.toASN1Primitive()
            val privateKeyPKCS1 = privateKeyPrimitive.getEncoded()
            arrayOf(encode(publicKeyPKCS1), encode(privateKeyPKCS1))
        }
    }
}

/**
 * 创建Cipher
 * @param rsaKey Key
 * @param encryptMode RSAEncryptMode
 * @param fillMode RSAFillMode
 * @param hashAlgorithm HashAlgorithm
 * @param mgfHashAlgorithm MGFHashAlgorithm
 * @param isEncrypt Boolean
 * @return Cipher
 */
@OptIn(ExperimentalEncodingApi::class)
private fun createCipher(
    rsaKey: Key,
    encryptMode: RSAEncryptMode,
    fillMode: RSAFillMode,
    hashAlgorithm: HashAlgorithm?,
    mgfHashAlgorithm: MGFHashAlgorithm?,
    isEncrypt: Boolean
): Cipher {
    val padding = if (fillMode == RSAFillMode.OAEP) "OAEPPadding" else fillMode.name
    val cipher = Cipher.getInstance("RSA/ECB/$padding")
    val mode = if (isEncrypt) Cipher.ENCRYPT_MODE else Cipher.DECRYPT_MODE
    if (fillMode == RSAFillMode.OAEP) {
        val hash = requireNotNull(hashAlgorithm) { "OAEP requires a hash" }.getText()
        val mgf = when (requireNotNull(mgfHashAlgorithm) { "OAEP requires an MGF hash" }) {
            MGFHashAlgorithm.SHA1 -> MGF1ParameterSpec.SHA1
            MGFHashAlgorithm.SHA256 -> MGF1ParameterSpec.SHA256
        }
        cipher.init(mode, rsaKey, OAEPParameterSpec(hash, "MGF1", mgf, PSource.PSpecified.DEFAULT))
    } else {
        cipher.init(mode, rsaKey)
    }
    return cipher
}

private fun HashAlgorithm.getText(): String {
    return when (this) {
        HashAlgorithm.SHA1 -> "SHA-1"
        HashAlgorithm.SHA256 -> "SHA-256"
    }
}

/**
 * 获取公钥
 * @param keyStr String
 * @return PublicKey
 */
@OptIn(ExperimentalEncodingApi::class)
fun getPublicKey(keyStr: String): PublicKey {
    var publicKey: PublicKey
    try {
        val keyFactory = KeyFactory.getInstance("RSA")
        publicKey = keyFactory.generatePublic(X509EncodedKeySpec(decode(cleanRSAKey(keyStr))))
        //println("public key format PKCS8")
    } catch (e: Exception) {
        try {
            val fullKey = "-----BEGIN RSA PUBLIC KEY-----\n${cleanRSAKey(keyStr)}\n-----END RSA PUBLIC KEY-----"
            val obj = PEMParser(fullKey.reader()).use { it.readObject() as SubjectPublicKeyInfo }
            val rsa = PublicKeyFactory.createKey(obj) as RSAKeyParameters
            val rsaSpec = RSAPublicKeySpec(rsa.modulus, rsa.exponent)
            val keyFactory = KeyFactory.getInstance("RSA", BouncyCastleProvider())
            publicKey = keyFactory.generatePublic(rsaSpec)
            //println("public key format PKCS1")
        } catch (e: Exception) {
            throw IllegalArgumentException("public key format error", e)
        }
    }
    return publicKey
}

/**
 * 获取私钥
 * @param keyStr String
 * @return PrivateKey
 */
@OptIn(ExperimentalEncodingApi::class)
fun getPrivateKey(keyStr: String): PrivateKey {
    val pemContent = decode(cleanRSAKey(keyStr))
    var privateKey: PrivateKey
    val keyFactory = KeyFactory.getInstance("RSA")
    try {
        privateKey = keyFactory.generatePrivate(PKCS8EncodedKeySpec(pemContent))
        //println("private key format PKCS8")
    } catch (e: Exception) {
        try {
            val asn1PrivateKey = RSAPrivateKey.getInstance(pemContent)
            val rsaPrivateKeySpec = RSAPrivateKeySpec(
                asn1PrivateKey.modulus,
                asn1PrivateKey.privateExponent
            )
            privateKey = keyFactory.generatePrivate(rsaPrivateKeySpec)
            //println("private key format PKCS1")
        } catch (e: Exception) {
            throw IllegalArgumentException("private key format error", e)
        }
    }
    return privateKey
}

/**
 * # RSA公钥加密
 * > RSA加密解密算法支持三种填充模式，分别是NoPadding、OAEP、PKCS1Padding，RSA填充是为了和公钥等长。
 * - OAEP：最优非对称加密填充，英文为：Optimal Asymmetric Encryption Padding，是RSA加密和RSA解密最新最安全的推荐填充模式。当填充模式选择OAEP时，必须选择参数Hash和MGFHash。
 * - PKCS1Padding：随机填充数据模式，每次加密的结果都不一样，是RSA加密和RSA解密使用最为广泛的填充模式。当填充模式选择PKCS1Padding时，无须选择参数Hash和MGFHash。
 * - NoPadding：不填充模式，是RSA加密和RSA解密使用较少的填充模式。当填充模式选择NoPadding时，无须选择参数Hash和MGFHash。
 * @param data String 待加密数据
 * @param publicKey String 公钥
 * @param encryptMode RSAEncryptMode 加密模式，默认RSAEncryptMode.ECB
 * @param fillMode RSAFillMode 填充模式，默认RSAFillMode.PKCS1Padding
 * @param hashAlgorithm HashAlgorithm 哈希算法，默认null
 * @param mgfHashAlgorithm HashAlgorithm MGF哈希算法，默认null
 * @return String 加密后的数据
 */
@OptIn(ExperimentalEncodingApi::class)
actual fun rsaPublicEncrypt(
    data: String,
    publicKey: String,
    encryptMode: RSAEncryptMode,
    fillMode: RSAFillMode,
    hashAlgorithm: HashAlgorithm?,
    mgfHashAlgorithm: MGFHashAlgorithm?
): String {
    val keyFactory = KeyFactory.getInstance("RSA")
    val rsaPublicKey = getPublicKey(publicKey)
    val cipher = createCipher(rsaPublicKey, encryptMode, fillMode, hashAlgorithm, mgfHashAlgorithm, true)
    val blockSize = keyFactory.getBlockSize(rsaPublicKey, true, fillMode, hashAlgorithm)
    val bytes = data.toByteArray(Charsets.UTF_8)
    validateRSAInput(bytes.size, blockSize, fillMode == RSAFillMode.NoPadding)
    return encode(cipher.doLongFinal(bytes, blockSize))
}

/**
 * # RSA私钥解密
 * > RSA加密解密算法支持三种填充模式，分别是NoPadding、OAEP、PKCS1Padding，RSA填充是为了和公钥等长。
 * - OAEP：最优非对称加密填充，英文为：Optimal Asymmetric Encryption Padding，是RSA加密和RSA解密最新最安全的推荐填充模式。当填充模式选择OAEP时，必须选择参数Hash和MGFHash。
 * - PKCS1Padding：随机填充数据模式，每次加密的结果都不一样，是RSA加密和RSA解密使用最为广泛的填充模式。当填充模式选择PKCS1Padding时，无须选择参数Hash和MGFHash。
 * - NoPadding：不填充模式，是RSA加密和RSA解密使用较少的填充模式。当填充模式选择NoPadding时，无须选择参数Hash和MGFHash。
 * @param data String 待解密数据
 * @param privateKey String 私钥
 * @param encryptMode RSAEncryptMode 加密模式，默认RSAEncryptMode.ECB
 * @param fillMode RSAFillMode 填充模式，默认RSAFillMode.PKCS1Padding
 * @param hashAlgorithm HashAlgorithm 哈希算法，默认null
 * @param mgfHashAlgorithm HashAlgorithm MGF哈希算法，默认null
 * @return String 解密后的数据
 */
@OptIn(ExperimentalEncodingApi::class)
actual fun rsaPrivateDecrypt(
    data: String,
    privateKey: String,
    encryptMode: RSAEncryptMode,
    fillMode: RSAFillMode,
    hashAlgorithm: HashAlgorithm?,
    mgfHashAlgorithm: MGFHashAlgorithm?
): String {
    val keyFactory = KeyFactory.getInstance("RSA")
    val rsaPrivateKey = getPrivateKey(privateKey)
    val cipher = createCipher(rsaPrivateKey, encryptMode, fillMode, hashAlgorithm, mgfHashAlgorithm, false)
    val blockSize = keyFactory.getBlockSize(rsaPrivateKey, false, fillMode, hashAlgorithm)
    val bytes = decodeRSACiphertext(data)
    validateRSAInput(bytes.size, blockSize, true)
    return String(cipher.doLongFinal(bytes, blockSize), Charsets.UTF_8)
}

/**
 * RSA私钥加密
 * > OAEP填充模式下不支持
 * @param data String 待加密数据
 * @param privateKey String 私钥
 * @param encryptMode RSAEncryptMode 加密模式，默认RSAEncryptMode.ECB
 * @param fillMode RSAFillMode 填充模式，默认RSAFillMode.PKCS1Padding
 * @param hashAlgorithm HashAlgorithm 哈希算法，默认null
 * @param mgfHashAlgorithm HashAlgorithm MGF哈希算法，默认null
 * @return String 加密后的数据
 */
@OptIn(ExperimentalEncodingApi::class)
fun rsaPrivateEncrypt(
    data: String,
    privateKey: String,
    encryptMode: RSAEncryptMode,
    fillMode: RSAFillMode,
    hashAlgorithm: HashAlgorithm?,
    mgfHashAlgorithm: MGFHashAlgorithm?
): String {
    val keyFactory = KeyFactory.getInstance("RSA")
    val rsaPrivateKey = getPrivateKey(privateKey)
    val cipher = createCipher(rsaPrivateKey, encryptMode, fillMode, hashAlgorithm, mgfHashAlgorithm, true)
    val blockSize = keyFactory.getBlockSize(rsaPrivateKey, true, fillMode, hashAlgorithm)
    val bytes = data.toByteArray(Charsets.UTF_8)
    validateRSAInput(bytes.size, blockSize, fillMode == RSAFillMode.NoPadding)
    return encode(cipher.doLongFinal(bytes, blockSize))
}

/**
 * RSA公钥解密
 * > OAEP填充模式下不支持
 * @param data String 待解密数据
 * @param publicKey String 公钥
 * @param encryptMode RSAEncryptMode 加密模式，默认RSAEncryptMode.ECB
 * @param fillMode RSAFillMode 填充模式，默认RSAFillMode.PKCS1Padding
 * @param hashAlgorithm HashAlgorithm 哈希算法，默认null
 * @param mgfHashAlgorithm HashAlgorithm MGF哈希算法，默认null
 * @return String 解密后的数据
 */
@OptIn(ExperimentalEncodingApi::class)
fun rsaPublicDecrypt(
    data: String,
    publicKey: String,
    encryptMode: RSAEncryptMode,
    fillMode: RSAFillMode,
    hashAlgorithm: HashAlgorithm?,
    mgfHashAlgorithm: MGFHashAlgorithm?
): String {
    val keyFactory = KeyFactory.getInstance("RSA")
    val rsaPublicKey = getPublicKey(publicKey)
    val cipher = createCipher(rsaPublicKey, encryptMode, fillMode, hashAlgorithm, mgfHashAlgorithm, false)
    val blockSize = keyFactory.getBlockSize(rsaPublicKey, false, fillMode, hashAlgorithm)
    val bytes = decodeRSACiphertext(data)
    validateRSAInput(bytes.size, blockSize, true)
    return String(cipher.doLongFinal(bytes, blockSize), Charsets.UTF_8)
}

/**
 * 获取分包大小
 * @receiver KeyFactory
 * @param key Key
 * @param fillMode RSAFillMode
 * @return Int
 */
private fun KeyFactory.getBlockSize(key: Key, isEncrypt: Boolean, fillMode: RSAFillMode, hash: HashAlgorithm?): Int {
    val bits = if (key is RSAPublicKey) {
        getKeySpec(key, RSAPublicKeySpec::class.java).modulus.bitLength()
    } else {
        getKeySpec(key, RSAPrivateKeySpec::class.java).modulus.bitLength()
    }
    val size = (bits + 7) / 8
    return if (isEncrypt) rsaBlockSize(size, fillMode, hash) else size
}

/**
 * 分包处理加密解密
 * @receiver Cipher
 * @param data ByteArray
 * @param blockSize Int
 * @return ByteArray
 */
private fun Cipher.doLongFinal(data: ByteArray, blockSize: Int): ByteArray {
    var offset = 0
    val blocks = mutableListOf<ByteArray>()

    while (offset < data.size) {
        val blockEnd = minOf(offset + blockSize, data.size)
        val block = doFinal(data, offset, blockEnd - offset)
        blocks.add(block)
        offset += blockSize
    }
    return joinRSABytes(blocks)
}
